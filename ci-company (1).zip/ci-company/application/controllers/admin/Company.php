<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Company extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Jakarta');
		setReferrer(current_url());

		if (!$this->session->has_userdata('AuthUser')) {
			setFlashError('Please login first', 'auth');
			redirect('auth');
		}

		if ($this->session->userdata('AuthUser')['user_level_id'] != 1) {
			hasReferrer() == true ? redirect(Referrer(), 'refresh') : redirect(base_url(), 'refresh');
		}
		
		$this->template->set_template('layouts/back');

		$this->load->library('user_agent');

		$this->load->model('CompanyModel');
		$this->load->model('ProvincesModel');
	}

	private $upload_errors = [];

	public function index()
	{
		$this->detail();
	}

	public function detail()
	{
		$session	= $this->session->userdata('AuthUser');
		$result		= [];

		$request = [
			'company' => $this->CompanyModel->getDetail(),
			'provinces' => $this->ProvincesModel->getAll(['limit' => 100])
		];

		foreach ($request as $key => $val) {
			$result[$key] = [];

			if (is_array($request[$key]) && array_key_exists('status', $request[$key])) {
				if ($request[$key]['status'] == 'success') {
					$result[$key] = $val['data'];
				}
			}
		}

		$this->template->title = 'Company Profile';
		$this->template->content->view('templates/back/company/detail', $result);

		$this->template->publish();
	}

	public function update()
	{
		$session	= $this->session->userdata('AuthUser');
		$result		= [];

		if ($this->input->method() == 'post') {
			$input = array_map('trim', $this->input->post());
			$file = false;

			if (is_uploaded_file($_FILES['logo']['tmp_name'])) {
				$input['logo'] = $_FILES['logo'];
				$file = true;
			}

			if ($file) {
				$file_path = './files/company/';
				$thumb_path = $file_path.'thumb/';

				if (!is_dir($file_path)) {
					mkdir($file_path, 0777, true);
				}

				if (!is_dir($thumb_path)) {
					mkdir($thumb_path, 0777, true);
				}

				$config_file = [
					'upload_path' => $file_path,
					'allowed_types' => 'jpg|jpeg|png',
					'max_size' => 150,
					//'max_width' => '1024',
					//'max_height' => '768',
					'encrypt_name' => true,
					//'file_name' => 'company_'.time()
				];

				$this->load->library('upload', $config_file);

				if (!$this->upload->do_upload('logo')) {
					$this->upload_errors['file'] = $this->upload->display_errors('','');
				} else {
					$upload_data = $this->upload->data();

					$config_resize = [
						'image_library' => 'gd2',
						'source_image' => $upload_data['full_path'],
						'create_thumb' => false,
						'maintain_ratio' => true,
						'quality' => '50%',
						'width' => 400,
						'height' => 100,
						'new_image' => $thumb_path
					];

					$this->load->library('image_lib', $config_resize);
					$this->image_lib->resize();
					$this->image_lib->clear();
				}
			}

			$validate = $this->validate($file);

			$this->form_validation->set_rules($validate);
			$this->form_validation->set_error_delimiters('','');

			if ($this->form_validation->run() == false) {
				if ($file) {
					if ($upload_data == true && file_exists($file_path.$upload_data['file_name'])) {
						unlink($file_path.$upload_data['file_name']);
					}
				}

				foreach ($input as $key => $val) {
					if (!empty(form_error($key))) {
						setFlashError(form_error($key), $key);
					}
				}

				setOldInput($input);
				redirect('admin/company');
			}

			$data = [
				'name'				=> ucwords($input['name']),
				'address_eng'		=> nl2space(ucwords($input['address_eng'])),
				'address_ind'		=> nl2space(ucwords($input['address_ind'])),
				'city_id'			=> $input['city'],
				'province_id'		=> $input['province'],
				'zip_code'			=> $input['zip_code'],
				'phone_1'			=> $input['phone_1'],
				'phone_2'			=> $input['phone_2'],
				'email_1'			=> $input['email_1'],
				'email_2'			=> $input['email_2'],
				'fax'				=> $input['fax'],
				'update_user_id'	=> $session['id']
			];

			$data = array_map('strClean', $data);

			if ($file) {
				$data['logo'] = $upload_data['file_name'];

				$request = $this->CompanyModel->getDetail();

				$file_old = null;

				if ($request['status'] == 'success') {
					$file_old = $request['data']['logo'];
				}
			}

			$request = $this->CompanyModel->update($data);

			if ($request['status'] == 'success') {
				setFlashSuccess('Data successfully updated.');

				if ($file) {
					if (file_exists($file_path.$file_old)) {
						unlink($file_path.$file_old);
					}

					if (file_exists($thumb_path.$file_old)) {
						unlink($thumb_path.$file_old);
					}
				}
			} else {
				setFlashError('An error occurred, please try again.');

				if ($file) {
					if (file_exists($file_path.$upload_data['file_name'])) {
						unlink($file_path.$upload_data['file_name']);
					}

					if (file_exists($thumb_path.$upload_data['file_name'])) {
						unlink($thumb_path.$upload_data['file_name']);
					}
				}
			}

			redirect('admin/company');
		}

		redirect($_SERVER['HTTP_REFERER']);
	}

	private function validate($file = false, $id = 0)
	{
		$validate = [
			[
				'field' => 'name',
				'label' => 'Name',
				'rules' => 'trim|required|max_length[100]|callback__regexName|xss_clean'
			],
			[
				'field' => 'address_eng',
				'label' => 'Address (English)',
				'rules' => 'trim|required|max_length[255]|callback__regexAddress|xss_clean'
			],
			[
				'field' => 'address_ind',
				'label' => 'Address (Indonesian)',
				'rules' => 'trim|required|max_length[255]|callback__regexAddress|xss_clean'
			],
			[
				'field' => 'province',
				'label' => 'Province',
				'rules' => 'trim|required|callback__regexNumeric|xss_clean'
			],
			[
				'field' => 'zip_code',
				'label' => 'Zip Code',
				'rules' => 'trim|required|max_length[6]|callback__regexNumeric|xss_clean'
			],
			[
				'field' => 'city',
				'label' => 'City',
				'rules' => 'trim|required|callback__regexNumeric|xss_clean'
			],
			[
				'field' => 'phone_1',
				'label' => 'Phone 1',
				'rules' => 'trim|required|max_length[30]|callback__regexNumeric|xss_clean'
			],
			[
				'field' => 'phone_2',
				'label' => 'Phone 2',
				'rules' => 'trim|required|max_length[30]|callback__regexNumeric|xss_clean'
			],
			[
				'field' => 'phone_2',
				'label' => 'Phone 2',
				'rules' => 'trim|max_length[30]|callback__regexNumeric|xss_clean'
			],
			[
				'field' => 'email_1',
				'label' => 'Email 1',
				'rules' => 'trim|required|max_length[100]|valid_email|xss_clean'
			],
			[
				'field' => 'email_2',
				'label' => 'Email 2',
				'rules' => 'trim|max_length[100]|valid_email|xss_clean'
			],
			[
				'field' => 'fax',
				'label' => 'fax',
				'rules' => 'trim|max_length[30]|callback__regexNumeric|xss_clean'
			],
		];

		if ($file) {
			$validate[] = [
				'field' => 'logo',
				'label' => 'Logo',
				'rules' => 'trim|callback__errorFile|xss_clean'
			];
		}

		return $validate;
	}

	public function _regexName($str = false)
	{
		if ($str) {
			if (!preg_match('/^[a-zA-Z0-9 .,\-\&]*$/', $str)) {
				$this->form_validation->set_message('_regexName', 'The %s format is invalid.');
				return false;
			}
		}

		return true;
	}

	public function _regexAddress($str = false)
	{
		if ($str) {
			if (!preg_match('/^[a-zA-Z0-9 \-,.()\r\n]*$/', $str)) {
				$this->form_validation->set_message('_regexAddress', 'The %s format is invalid.');
				return false;
			}
		}

		return true;
	}

	public function _regexNumeric($str = false)
	{
		if ($str) {
			if (!preg_match('/^[0-9]*$/', $str)) {
				$this->form_validation->set_message('_regexNumeric', 'The %s format is invalid.');
				return false;
			}
		}

		return true;
	}

	public function _formatDate($str = false)
	{
		if ($str) {
			$date = DateTime::createFromFormat('Y-m-d', $str);
			$error = DateTime::getLastErrors();

			if ($error['warning_count'] > 0 || $error['error_count'] > 0) {
				$this->form_validation->set_message('_formatDate', 'The %s format is invalid.');
				return false;
			}
		}

		return true;
    }

	public function _errorFile($str)
	{
		if (isset($this->upload_errors['file'])) {
			$this->form_validation->set_message('_errorFile', $this->upload_errors['file']);
			return false;
		}

		return true;
	}
}
