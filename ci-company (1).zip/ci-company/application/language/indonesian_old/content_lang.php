<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['welcome'] = 'Selamat Datang';
$lang['message'] = 'Misi kami adalah menyediakan layanan desain web yang profesional dan sangat kreatif serta layanan terkait lainnya kepada berbagai pelanggan potensial di seluruh dunia.';
